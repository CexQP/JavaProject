package OnlineMarket;

import javax.swing.*;
import java.awt.*;

public class BaseFrame extends JFrame {

    public BaseFrame() {
        try {
            Image icon = Toolkit.getDefaultToolkit().getImage(
                    BaseFrame.class.getResource("/resources/icon/icon.png")
            );
            setIconImage(icon);
        } catch (Exception e) {
            System.out.println("Icon yüklenemedi!");
        }
    }
}