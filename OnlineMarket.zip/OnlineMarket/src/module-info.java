/**
 * 
 */
/**
 * 
 */
module Online_Market {
	requires java.desktop;
	requires java.sql;
}