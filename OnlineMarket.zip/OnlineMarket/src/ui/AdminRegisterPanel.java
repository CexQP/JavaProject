package ui;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import db.DBConnection;

public class AdminRegisterPanel extends JPanel {

    private JTextField txtAdSoyad;
    private JTextField txtPhone;
    private JTextField txtUser;
    private JPasswordField txtPass;

    public AdminRegisterPanel() {

        setLayout(null);
        setBackground(Color.WHITE);

        JLabel lblTitle = new JLabel("Yönetici Kayıt");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitle.setForeground(new Color(45, 118, 232));
        lblTitle.setBounds(60, 20, 300, 30);
        add(lblTitle);

        JLabel lblSub = new JLabel("Yeni yönetici hesabı oluştur");
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSub.setForeground(Color.GRAY);
        lblSub.setBounds(60, 50, 300, 20);
        add(lblSub);

        JLabel lblAdSoyad = new JLabel("Ad Soyad");
        lblAdSoyad.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblAdSoyad.setBounds(60, 90, 120, 25);
        add(lblAdSoyad);

        txtAdSoyad = new JTextField();
        txtAdSoyad.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtAdSoyad.setBounds(200, 90, 260, 32);
        add(txtAdSoyad);

        JLabel lblPhone = new JLabel("Telefon No");
        lblPhone.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblPhone.setBounds(60, 140, 120, 25);
        add(lblPhone);

        txtPhone = new JTextField();
        txtPhone.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtPhone.setBounds(200, 140, 260, 32);
        txtPhone.setToolTipText("Örn: 0555XXXXXXX");
        add(txtPhone);

        JLabel lblUser = new JLabel("Kullanıcı Adı");
        lblUser.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblUser.setBounds(60, 190, 120, 25);
        add(lblUser);

        txtUser = new JTextField();
        txtUser.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtUser.setBounds(200, 190, 260, 32); 
        add(txtUser);

        // 4. PAROLA
        JLabel lblPass = new JLabel("Parola");
        lblPass.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblPass.setBounds(60, 240, 120, 25); 
        add(lblPass);

        txtPass = new JPasswordField();
        txtPass.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtPass.setBounds(200, 240, 260, 32);
        add(txtPass);

        JButton btnKaydet = new JButton("Yönetici Ekle");
        btnKaydet.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnKaydet.setBounds(200, 300, 200, 42);
        btnKaydet.setBackground(new Color(45, 118, 232));
        btnKaydet.setForeground(Color.WHITE);
        btnKaydet.setFocusPainted(false);
        add(btnKaydet);

        btnKaydet.addActionListener(e -> saveAdmin());
    }

    private void saveAdmin() {

        String adSoyad = txtAdSoyad.getText().trim();
        String phone = txtPhone.getText().trim();
        String user = txtUser.getText().trim();
        String pass = new String(txtPass.getPassword()).trim();

        if (adSoyad.isEmpty() || phone.isEmpty() || user.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Tüm alanlar doldurulmalıdır!",
                    "Uyarı",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!phone.matches("[0-9]+") || phone.length() < 10) {
             JOptionPane.showMessageDialog(this,
                    "Lütfen geçerli bir telefon numarası giriniz (Sadece rakam).",
                    "Hatalı Giriş",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "INSERT INTO yonetici (ad_soyad, telefon, kullanici_adi, sifre) VALUES (?,?,?,?)")) {

            ps.setString(1, adSoyad);
            ps.setString(2, phone);
            ps.setString(3, user);
            ps.setString(4, pass);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this,
                    "Yönetici başarıyla eklendi",
                    "Başarılı",
                    JOptionPane.INFORMATION_MESSAGE);

            txtAdSoyad.setText("");
            txtPhone.setText("");
            txtUser.setText("");
            txtPass.setText("");

        } catch (SQLIntegrityConstraintViolationException ex) {
            JOptionPane.showMessageDialog(this,
                    "Bu kullanıcı adı zaten mevcut!",
                    "Uyarı",
                    JOptionPane.WARNING_MESSAGE);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Kayıt sırasında hata oluştu:\n" + e.getMessage(),
                    "Hata",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}