package ui;

import javax.swing.*;

import OnlineMarket.BaseFrame;

import java.awt.*;
import java.sql.*;
import db.DBConnection;

public class MemberRegisterFrame extends BaseFrame {

    private JTextField txtName, txtUsername, txtPhone;
    private JTextArea txtAddress;
    private JPasswordField txtPassword;

    public MemberRegisterFrame() {

    	JButton btnBack = new JButton() {
    	    @Override
    	    protected void paintComponent(Graphics g) {
    	        super.paintComponent(g);
    	        Graphics2D g2 = (Graphics2D) g;
    	        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    	        g2.setStroke(new BasicStroke(2));
    	        g2.setColor(new Color(30, 30, 30)); 

    	        int w = getWidth();
    	        int h = getHeight();

    	        g2.drawLine(w - 12, h / 2, 12, h / 2);
    	        g2.drawLine(12, h / 2, 20, h / 2 - 8);
    	        g2.drawLine(12, h / 2, 20, h / 2 + 8);
    	    }
    	};

    	btnBack.setBounds(20, 20, 40, 30);
    	btnBack.setContentAreaFilled(false);
    	btnBack.setBorderPainted(false);
    	btnBack.setFocusPainted(false);
    	btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
    	btnBack.setToolTipText("Geri Dön");
    	add(btnBack);


        setTitle("Üye Kayıt");
        setSize(520, 460);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(null);
        panel.setBackground(Color.WHITE);
        getContentPane().add(panel);

        JLabel lblTitle = new JLabel("Üye Kayıt");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setBounds(200, 20, 200, 30);
        panel.add(lblTitle);

        JLabel lblSub = new JLabel("Yeni hesap oluşturun");
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSub.setForeground(Color.GRAY);
        lblSub.setBounds(185, 50, 250, 20);
        panel.add(lblSub);

        int leftLabel = 90;
        int leftField = 230;
        int width = 190;
        int y = 90;
        int gap = 45;

        panel.add(createLabel("Ad Soyad", leftLabel, y));
        txtName = createField(leftField, y, width);
        panel.add(txtName);

        y += gap;
        panel.add(createLabel("Adres", leftLabel, y));
        txtAddress = new JTextArea();
        txtAddress.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtAddress.setLineWrap(true);
        txtAddress.setWrapStyleWord(true);

        JScrollPane spAddress = new JScrollPane(txtAddress);
        spAddress.setBounds(leftField, y, width, 55);
        panel.add(spAddress);

        y += 65;
        panel.add(createLabel("Telefon", leftLabel, y));
        txtPhone = createField(leftField, y, width);
        panel.add(txtPhone);

        y += gap;
        panel.add(createLabel("Kullanıcı Adı", leftLabel, y));
        txtUsername = createField(leftField, y, width);
        panel.add(txtUsername);

        y += gap;
        panel.add(createLabel("Parola", leftLabel, y));
        txtPassword = new JPasswordField();
        txtPassword.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtPassword.setBounds(leftField, y, width, 30);
        panel.add(txtPassword);

        JButton btnSave = new JButton("Kayıt Ol");
        btnSave.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnSave.setBounds(190, y + 55, 140, 42);
        btnSave.setBackground(new Color(45, 118, 232));
        btnSave.setForeground(Color.WHITE);
        btnSave.setFocusPainted(false);
        panel.add(btnSave);

        btnSave.addActionListener(e -> register());
        
        btnBack.addActionListener(e -> {
            dispose();
        });
    }

    private void register() {

        String name = txtName.getText().trim();
        String address = txtAddress.getText().trim();
        String phone = txtPhone.getText().trim();
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword()).trim();

        if (name.isEmpty() || address.isEmpty() || phone.isEmpty()
                || username.isEmpty() || password.isEmpty()) {

            JOptionPane.showMessageDialog(this,
                    "Tüm alanlar doldurulmalıdır!",
                    "Uyarı",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!phone.matches("\\d{10,15}")) {
            JOptionPane.showMessageDialog(this,
                    "Telefon numarası sadece rakam olmalıdır (10-15 hane)",
                    "Hatalı Telefon",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        String sql =
                "INSERT INTO members (name, address, phone, username, password) " +
                "VALUES (?,?,?,?,?)";

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, name);
            ps.setString(2, address);
            ps.setString(3, phone);
            ps.setString(4, username);
            ps.setString(5, password);

            ps.executeUpdate();

            JOptionPane.showMessageDialog(this,
                    "Üye kaydı başarılı",
                    "Başarılı",
                    JOptionPane.INFORMATION_MESSAGE);

            dispose();

        } catch (SQLIntegrityConstraintViolationException ex) {
            JOptionPane.showMessageDialog(this,
                    "Bu kullanıcı adı zaten kullanılıyor",
                    "Uyarı",
                    JOptionPane.WARNING_MESSAGE);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Kayıt sırasında hata oluştu",
                    "Hata",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private JLabel createLabel(String text, int x, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lbl.setBounds(x, y, 120, 25);
        return lbl;
    }

    private JTextField createField(int x, int y, int w) {
        JTextField tf = new JTextField();
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tf.setBounds(x, y, w, 30);
        return tf;
    }
}
