package ui;

import db.DBConnection;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.sql.*;

public class MemberProfilePanel extends JPanel {

    JTextField txtUsername, txtName;
    JTextArea txtAddress;
    JPasswordField txtPass;
    int memberId;

    private final Color PRIMARY_COLOR = new Color(45, 118, 232);
    private final Color BG_COLOR = new Color(250, 250, 250);
    private final Color BORDER_COLOR = new Color(200, 200, 200);

    private final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 32);
    private final Font LABEL_FONT = new Font("Segoe UI", Font.PLAIN, 16);
    private final Font INPUT_FONT = new Font("Segoe UI", Font.PLAIN, 15);

    public MemberProfilePanel(int memberId) {
        this.memberId = memberId;

        setLayout(new GridBagLayout());
        setBackground(BG_COLOR);
        setBorder(new EmptyBorder(40, 80, 40, 80));

        GridBagConstraints baseGc = new GridBagConstraints();
        baseGc.insets = new Insets(12, 10, 12, 10);
        baseGc.fill = GridBagConstraints.HORIZONTAL;
        baseGc.anchor = GridBagConstraints.CENTER;

        JLabel lblTitle = new JLabel("Profil Düzenle");
        lblTitle.setFont(TITLE_FONT);
        lblTitle.setForeground(PRIMARY_COLOR);

        GridBagConstraints gcTitle = (GridBagConstraints) baseGc.clone();
        gcTitle.gridx = 0;
        gcTitle.gridy = 0;
        gcTitle.gridwidth = 2;
        gcTitle.insets = new Insets(10, 10, 40, 10);
        add(lblTitle, gcTitle);

        addLabel("Ad Soyad:", 0, 1, baseGc);

        txtName = new JTextField();
        styleField(txtName);
        addField(txtName, 1, 1, baseGc);

        addLabel("Adres:", 0, 2, baseGc);

        txtAddress = new JTextArea(8, 20); 
        txtAddress.setLineWrap(true);
        txtAddress.setWrapStyleWord(true);
        txtAddress.setFont(INPUT_FONT);
        txtAddress.setBorder(new CompoundBorder(
                new LineBorder(BORDER_COLOR, 1),
                new EmptyBorder(10, 10, 10, 10)
        ));

        JScrollPane addressScroll = new JScrollPane(txtAddress);
        addressScroll.setBorder(null);

        GridBagConstraints gcAddress = (GridBagConstraints) baseGc.clone();
        gcAddress.gridx = 1;
        gcAddress.gridy = 2;
        gcAddress.weightx = 1;
        gcAddress.ipady = 80; 
        add(addressScroll, gcAddress);

        /* ===== AYIRAÇ ===== */
        JSeparator sep = new JSeparator();
        sep.setForeground(BORDER_COLOR);

        GridBagConstraints gcSep = (GridBagConstraints) baseGc.clone();
        gcSep.gridx = 0;
        gcSep.gridy = 3;
        gcSep.gridwidth = 2;
        gcSep.insets = new Insets(30, 0, 30, 0);
        add(sep, gcSep);

        addLabel("Kullanıcı Adı:", 0, 4, baseGc);

        txtUsername = new JTextField();
        styleField(txtUsername);
        addField(txtUsername, 1, 4, baseGc);

        /* ===== PAROLA ===== */
        addLabel("Yeni Parola:", 0, 5, baseGc);

        txtPass = new JPasswordField();
        styleField(txtPass);
        addField(txtPass, 1, 5, baseGc);

        JButton btnUpdate = new JButton("GÜNCELLE");
        btnUpdate.setFont(new Font("Segoe UI", Font.BOLD, 14)); 
        btnUpdate.setBackground(PRIMARY_COLOR);
        btnUpdate.setForeground(Color.WHITE);
        btnUpdate.setFocusPainted(false);
        btnUpdate.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnUpdate.setPreferredSize(new Dimension(180, 40));

        GridBagConstraints gcBtn = (GridBagConstraints) baseGc.clone();
        gcBtn.gridx = 1;
        gcBtn.gridy = 6;
        gcBtn.weighty = 1;
        gcBtn.anchor = GridBagConstraints.NORTHEAST;
        gcBtn.insets = new Insets(30, 10, 10, 10);
        add(btnUpdate, gcBtn);

        btnUpdate.addActionListener(e -> updateInfo());

        loadInfo();
    }

    private void addLabel(String text, int x, int y, GridBagConstraints base) {
        JLabel label = new JLabel(text);
        label.setFont(LABEL_FONT);
        label.setForeground(Color.DARK_GRAY);

        GridBagConstraints gc = (GridBagConstraints) base.clone();
        gc.gridx = x;
        gc.gridy = y;
        gc.weightx = 0.2;
        add(label, gc);
    }

    private void addField(JComponent field, int x, int y, GridBagConstraints base) {
        GridBagConstraints gc = (GridBagConstraints) base.clone();
        gc.gridx = x;
        gc.gridy = y;
        gc.weightx = 0.8;
        add(field, gc);
    }

    private void styleField(JTextField field) {
        field.setFont(INPUT_FONT);
        field.setBorder(new CompoundBorder(
                new LineBorder(BORDER_COLOR, 1),
                new EmptyBorder(10, 10, 10, 10)
        ));
    }

    void loadInfo() {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT username, name, address FROM members WHERE id=?")) {

            ps.setInt(1, memberId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                txtUsername.setText(rs.getString("username"));
                txtName.setText(rs.getString("name"));
                txtAddress.setText(rs.getString("address"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void updateInfo() {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "UPDATE members SET username=?, name=?, address=?, password=? WHERE id=?")) {

            ps.setString(1, txtUsername.getText());
            ps.setString(2, txtName.getText());
            ps.setString(3, txtAddress.getText());
            ps.setString(4, new String(txtPass.getPassword()));
            ps.setInt(5, memberId);

            ps.executeUpdate();
            JOptionPane.showMessageDialog(this,
                    "Profil bilgileriniz başarıyla güncellendi.");

        } catch (SQLIntegrityConstraintViolationException ex) {
            JOptionPane.showMessageDialog(this,
                    "Bu kullanıcı adı zaten kullanılıyor!",
                    "Hata",
                    JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}