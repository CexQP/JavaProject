package ui;

import javax.swing.*;

import OnlineMarket.BaseFrame;

import java.awt.*;
import dao.AdminDAO;

public class LoginFrame extends BaseFrame {

    private JTextField txtUser;
    private JPasswordField txtPass;

    public LoginFrame() {

        setTitle("Yönetici Girişi");
        setSize(500, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setLayout(null);
        getContentPane().add(panel);

        /* ===== BAŞLIK ===== */
        JLabel lblTitle = new JLabel("Yönetici Girişi");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setBounds(170, 30, 200, 30);
        panel.add(lblTitle);

        JLabel lblSub = new JLabel("Yetkili kullanıcı girişi");
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSub.setForeground(Color.GRAY);
        lblSub.setBounds(180, 59, 120, 20);
        panel.add(lblSub);
        
        JButton btnBack = new JButton() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setStroke(new BasicStroke(2));
                g2.setColor(new Color(30, 30, 30));

                int w = getWidth();
                int h = getHeight();

                g2.drawLine(w - 12, h / 2, 12, h / 2);         
                g2.drawLine(12, h / 2, 20, h / 2 - 8);   
                g2.drawLine(12, h / 2, 20, h / 2 + 8);     
            }
        };

        btnBack.setBounds(20, 18, 40, 30);
        btnBack.setContentAreaFilled(false);
        btnBack.setBorderPainted(false);
        btnBack.setFocusPainted(false);
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.setToolTipText("Geri Dön");
        panel.add(btnBack);






        JLabel lblUser = new JLabel("Kullanıcı Adı");
        lblUser.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblUser.setBounds(100, 120, 120, 25);
        panel.add(lblUser);

        txtUser = new JTextField();
        txtUser.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtUser.setBounds(230, 120, 170, 30);
        panel.add(txtUser);

        JLabel lblPass = new JLabel("Parola");
        lblPass.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblPass.setBounds(100, 170, 120, 25);
        panel.add(lblPass);

        txtPass = new JPasswordField();
        txtPass.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtPass.setBounds(230, 170, 170, 30);
        panel.add(txtPass);

        JButton btnLogin = new JButton("Giriş Yap");
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnLogin.setBounds(180, 230, 140, 40);
        btnLogin.setBackground(new Color(45, 118, 232));
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        panel.add(btnLogin);

        btnLogin.addActionListener(e -> login());
        getRootPane().setDefaultButton(btnLogin);
        
        btnBack.addActionListener(e -> {
            dispose();
            new MainLoginFrame().setVisible(true);
        });



    }

    private void login() {

        String username = txtUser.getText();
        String password = new String(txtPass.getPassword());

        if (AdminDAO.login(username, password)) {
            JOptionPane.showMessageDialog(this, "Yönetici girişi başarılı");
            dispose();
            new AdminFrame().setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Hatalı kullanıcı adı veya şifre",
                    "Giriş Hatası",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
