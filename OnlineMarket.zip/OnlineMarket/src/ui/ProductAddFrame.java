package ui;

import javax.swing.*;
import java.sql.*;

import db.DBConnection;

public class ProductAddFrame extends JFrame {

    private JTextField txtUrunAdi;
    private JTextField txtFiyat;
    private JTextField txtStok;

    public ProductAddFrame() {
        setTitle("Ürün Ekle");
        setSize(350, 250);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel l1 = new JLabel("Ürün Adı:");
        l1.setBounds(30, 30, 100, 25);
        add(l1);

        txtUrunAdi = new JTextField();
        txtUrunAdi.setBounds(130, 30, 150, 25);
        add(txtUrunAdi);

        JLabel l2 = new JLabel("Fiyat:");
        l2.setBounds(30, 70, 100, 25);
        add(l2);

        txtFiyat = new JTextField();
        txtFiyat.setBounds(130, 70, 150, 25);
        add(txtFiyat);

        JLabel l3 = new JLabel("Stok:");
        l3.setBounds(30, 110, 100, 25);
        add(l3);

        txtStok = new JTextField();
        txtStok.setBounds(130, 110, 150, 25);
        add(txtStok);

        JButton btnKaydet = new JButton("Kaydet");
        btnKaydet.setBounds(120, 160, 100, 30);
        add(btnKaydet);

        btnKaydet.addActionListener(e -> urunKaydet());
    }

    private void urunKaydet() {
        String urunAdi = txtUrunAdi.getText().trim();
        String fiyatStr = txtFiyat.getText().trim();
        String stokStr = txtStok.getText().trim();

        if (urunAdi.isEmpty() || fiyatStr.isEmpty() || stokStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tüm alanları doldurun!");
            return;
        }

        try {
            double fiyat = Double.parseDouble(fiyatStr);
            int stok = Integer.parseInt(stokStr);

            try (Connection c = DBConnection.getConnection();
                 PreparedStatement ps = c.prepareStatement(
                         "INSERT INTO urunler (urun_adi, fiyat, stok) VALUES (?, ?, ?)")) {

                ps.setString(1, urunAdi);
                ps.setDouble(2, fiyat);
                ps.setInt(3, stok);
                ps.executeUpdate();

                JOptionPane.showMessageDialog(this, "Ürün eklendi");
                dispose();
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Fiyat ve stok sayı olmalı!");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Veritabanı hatası!");
        }
    }
}
