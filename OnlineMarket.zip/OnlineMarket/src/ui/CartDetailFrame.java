package ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.sql.*;
import db.DBConnection;

public class CartDetailFrame extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private int sepetId;

    public CartDetailFrame(int sepetId) {
        this.sepetId = sepetId;

        setTitle("Sepet Detayı - ID: " + sepetId);
        setSize(550, 450);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        JLabel lblTitle = new JLabel("Sepet İçeriği (ID: " + sepetId + ")");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitle.setBounds(30, 20, 300, 30);
        add(lblTitle);

        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        model.addColumn("Ürün Adı");
        model.addColumn("Adet");
        model.addColumn("Birim Fiyat");
        model.addColumn("Toplam");

        table = new JTable(model);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setRowHeight(25);
        table.setSelectionBackground(new Color(45, 118, 232, 50));
        table.setGridColor(new Color(230, 230, 230));

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setBackground(new Color(245, 245, 245));
        header.setReorderingAllowed(false);

        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(30, 70, 475, 250);
        sp.getViewport().setBackground(Color.WHITE);
        add(sp);

        JButton btnKapat = new JButton("Kapat");
        btnKapat.setBounds(325, 340, 180, 42);
        btnKapat.setBackground(new Color(45, 118, 232));
        btnKapat.setForeground(Color.WHITE);
        btnKapat.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnKapat.setFocusPainted(false);
        btnKapat.setBorderPainted(false);
        btnKapat.addActionListener(e -> dispose());
        add(btnKapat);

        loadDetails();
    }

    private void loadDetails() {
        model.setRowCount(0);

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT u.urun_adi, su.adet, u.fiyat " +
                     "FROM sepet_urun su " +
                     "JOIN urunler u ON su.urun_id = u.id " +
                     "WHERE su.sepet_id=?")) {

            ps.setInt(1, sepetId);
            ResultSet rs = ps.executeQuery();

            double genelToplam = 0;

            while (rs.next()) {
                String ad = rs.getString("urun_adi");
                int adet = rs.getInt("adet");
                double fiyat = rs.getDouble("fiyat");
                double toplam = adet * fiyat;
                genelToplam += toplam;

                model.addRow(new Object[]{
                        ad,
                        adet,
                        String.format("%.2f ₺", fiyat),
                        String.format("%.2f ₺", toplam)
                });
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Veriler yüklenirken hata oluştu!");
        }
    }
}