package ui;

import javax.swing.*;
import java.awt.*;
import OnlineMarket.BaseFrame;

public class MainLoginFrame extends BaseFrame {

    public MainLoginFrame() {

        setTitle("Online Market");
        setSize(600, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(Color.WHITE);
        mainPanel.setLayout(null);
        getContentPane().add(mainPanel);

        JLabel lblTitle = new JLabel("Kapıma Gelsin");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitle.setForeground(new Color(45, 118, 232));
        lblTitle.setBounds(196, 11, 250, 60);
        mainPanel.add(lblTitle);

        JLabel lblSubTitle = new JLabel("Online Market Sistemi");
        lblSubTitle.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblSubTitle.setForeground(new Color(120, 120, 120));
        lblSubTitle.setBounds(205, 60, 200, 25);
        mainPanel.add(lblSubTitle);

        JButton btnAdmin = createButton("Yönetici Girişi");
        btnAdmin.setBounds(200, 140, 200, 45);
        mainPanel.add(btnAdmin);

        JButton btnMemberLogin = createButton("Üye Girişi");
        btnMemberLogin.setBounds(200, 200, 200, 45);
        mainPanel.add(btnMemberLogin);

        JButton btnMemberRegister = createButton("Üye Kayıt");
        btnMemberRegister.setBounds(200, 260, 200, 45);
        mainPanel.add(btnMemberRegister);

        JButton btnExit = new JButton("Çıkış");
        btnExit.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnExit.setBounds(200, 320, 200, 40);
        btnExit.setBackground(new Color(220, 53, 69));
        btnExit.setForeground(Color.WHITE);
        btnExit.setFocusPainted(false);
        mainPanel.add(btnExit);

        btnAdmin.addActionListener(e -> {
            new LoginFrame().setVisible(true);
            dispose();
        });

        btnMemberLogin.addActionListener(e -> {
            new MemberLoginFrame().setVisible(true);
            dispose();
        });

        btnMemberRegister.addActionListener(e -> {
            new MemberRegisterFrame().setVisible(true);
        });

        btnExit.addActionListener(e -> System.exit(0));
    }

    private JButton createButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btn.setBackground(new Color(45, 118, 232));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        return btn;
    }

    public static void main(String[] args) {
        new MainLoginFrame().setVisible(true);
    }
}
