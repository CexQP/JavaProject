package ui;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import db.DBConnection;

public class ProductUpdateDialog extends JDialog {

    private JTextField txtAd, txtFiyat, txtStok, txtBirimMiktar;
    private JComboBox<String> cmbBirim;
    private int productId;
    private ProductManager parent;

    public ProductUpdateDialog(int productId, ProductManager parent) {
        this.productId = productId;
        this.parent = parent; 

        setTitle("Ürün Güncelle");
        setSize(420, 430);
        setLocationRelativeTo(null);
        setLayout(null);
        setModal(true);
        getContentPane().setBackground(Color.WHITE);

        JLabel lblTitle = new JLabel("Ürün Güncelle");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitle.setBounds(30, 20, 250, 30);
        lblTitle.setForeground(new Color(45, 118, 232));
        add(lblTitle);

        int x = 40;
        int y = 70;
        int w = 320;
        int h = 35;
        int gap = 60;

        addLabel("Ürün Adı", x, y);
        txtAd = addField(x, y + 25, w);

        y += gap;
        addLabel("Fiyat (TL)", x, y);
        txtFiyat = addField(x, y + 25, w);

        y += gap;
        addLabel("Stok", x, y);
        txtStok = addField(x, y + 25, w);

        y += gap;
        addLabel("Miktar & Birim", x, y);
        txtBirimMiktar = addField(x, y + 25, 150);

        cmbBirim = new JComboBox<>(new String[]{"ADET", "KG", "GR", "LT", "PKT"});
        cmbBirim.setBounds(x + 170, y + 25, 150, h);
        cmbBirim.setBackground(Color.WHITE);
        add(cmbBirim);

        JButton btnSave = new JButton("Güncelle ve Kapat");
        btnSave.setBounds(x, y + gap + 20, w, 45);
        btnSave.setBackground(new Color(45, 118, 232));
        btnSave.setForeground(Color.WHITE);
        btnSave.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnSave.setFocusPainted(false);
        btnSave.addActionListener(e -> updateProduct());
        add(btnSave);

        loadProduct();
    }

    private void loadProduct() {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT urun_adi, fiyat, stok, birim_miktar, birim FROM urunler WHERE id=?")) {

            ps.setInt(1, productId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                txtAd.setText(rs.getString("urun_adi"));
                txtFiyat.setText(String.valueOf(rs.getDouble("fiyat")));
                txtStok.setText(String.valueOf(rs.getInt("stok")));
                txtBirimMiktar.setText(String.valueOf(rs.getDouble("birim_miktar")));
                cmbBirim.setSelectedItem(rs.getString("birim"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateProduct() {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "UPDATE urunler SET urun_adi=?, fiyat=?, stok=?, birim_miktar=?, birim=? WHERE id=?")) {

            ps.setString(1, txtAd.getText().trim());
            ps.setDouble(2, Double.parseDouble(txtFiyat.getText()));
            ps.setInt(3, Integer.parseInt(txtStok.getText()));
            ps.setDouble(4, Double.parseDouble(txtBirimMiktar.getText()));
            ps.setString(5, cmbBirim.getSelectedItem().toString());
            ps.setInt(6, productId);

            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Ürün güncellendi");

            if (parent != null) {
                parent.loadProducts();
            }
            
            dispose();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Hatalı giriş! Değerleri kontrol ediniz.");
        }
    }

    private void addLabel(String text, int x, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lbl.setForeground(Color.DARK_GRAY);
        lbl.setBounds(x, y, 200, 20);
        add(lbl);
    }

    private JTextField addField(int x, int y, int w) {
        JTextField tf = new JTextField();
        tf.setBounds(x, y, w, 35);
        tf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        add(tf);
        return tf;
    }
}