package ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.sql.*;
import db.DBConnection;

public class MemberAdminPanel extends JPanel {

    private JTable table;
    private DefaultTableModel model;
    private JComboBox<String> cmbType;

    public MemberAdminPanel() {

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        add(createListPanel(), BorderLayout.CENTER);

        loadData();
    }


    private JPanel createListPanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setBackground(Color.WHITE);

        panel.setBorder(new EmptyBorder(30, 40, 30, 40));

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(Color.WHITE);

        JLabel lblListTitle = new JLabel("Kullanıcı & Yönetici Listesi");
        lblListTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblListTitle.setForeground(new Color(60, 60, 60));

        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        filterPanel.setBackground(Color.WHITE);
        JLabel lblFilter = new JLabel("Görüntüle: ");
        lblFilter.setFont(new Font("Segoe UI", Font.BOLD, 14));
        
        cmbType = new JComboBox<>(new String[]{"Üyeler", "Yöneticiler"});
        cmbType.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        cmbType.setPreferredSize(new Dimension(160, 35));
        cmbType.setFocusable(false);
        cmbType.addActionListener(e -> loadData());

        filterPanel.add(lblFilter);
        filterPanel.add(cmbType);

        topPanel.add(lblListTitle, BorderLayout.WEST);
        topPanel.add(filterPanel, BorderLayout.EAST);
        panel.add(topPanel, BorderLayout.NORTH);

        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        table = new JTable(model);
        table.setRowHeight(45); 
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        
        Color lightGrayBg = new Color(248, 249, 250); 
        Color textBlack = Color.BLACK;
        Color headerColor = new Color(230, 230, 230);
        Color selectionColor = new Color(200, 220, 240); 

        table.setBackground(lightGrayBg);
        table.setForeground(textBlack);
        table.setSelectionBackground(selectionColor);
        table.setSelectionForeground(Color.BLACK);
        
        table.setGridColor(Color.WHITE); 
        table.setShowVerticalLines(false);
        table.setShowHorizontalLines(true);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(headerColor);
        header.setForeground(textBlack);
        header.setPreferredSize(new Dimension(0, 45));
        header.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));

        JScrollPane sp = new JScrollPane(table);
        sp.getViewport().setBackground(lightGrayBg);
        sp.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220)));
        
        panel.add(sp, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.setBackground(Color.WHITE);

        JButton btnDelete = new JButton("Seçili Kaydı Sil");
        btnDelete.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnDelete.setBackground(new Color(220, 53, 69)); 
        btnDelete.setForeground(Color.WHITE);
        btnDelete.setFocusPainted(false);
        btnDelete.setBorderPainted(false);
        btnDelete.setPreferredSize(new Dimension(180, 45));
        btnDelete.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btnDelete.addActionListener(e -> deleteSelected());
        bottomPanel.add(btnDelete);
        
        panel.add(bottomPanel, BorderLayout.SOUTH);

        return panel;
    }

    private void loadData() {
        String selected = (String) cmbType.getSelectedItem();
        model.setRowCount(0);
        model.setColumnCount(0);

        model.addColumn("ID");
        model.addColumn("Ad Soyad");
        if ("Üyeler".equals(selected)) {
            model.addColumn("Kullanıcı Adı");
            model.addColumn("Adres");
        } else {
            model.addColumn("Kullanıcı Adı");
        }
        model.addColumn("Telefon");
        
        

        table.getColumnModel().getColumn(0).setMaxWidth(60);

        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement()) {

            ResultSet rs;
            if ("Üyeler".equals(selected)) {
                rs = st.executeQuery("SELECT id, name, username, phone, address FROM members ORDER BY id DESC");
                while (rs.next()) {
                	model.addRow(new Object[]{
                		    rs.getInt("id"),
                		    rs.getString("name"),  
                		    rs.getString("username"),
                		    rs.getString("phone"), 
                		    rs.getString("address")
                		});

                }
            } else {
                rs = st.executeQuery("SELECT id, ad_soyad, kullanici_adi, telefon FROM yonetici ORDER BY id DESC");
                while (rs.next()) {
                	model.addRow(new Object[]{
                		    rs.getInt("id"),
                		    rs.getString("ad_soyad"),
                		    rs.getString("kullanici_adi"),
                		    rs.getString("telefon"), 
                		    
                		});

                }
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void deleteSelected() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Lütfen silinecek kişiyi seçiniz.", "Uyarı", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = (int) model.getValueAt(row, 0);
        String type = (String) cmbType.getSelectedItem();
        
        int confirm = JOptionPane.showConfirmDialog(this, 
                "Seçili kaydı silmek istediğinize emin misiniz?", 
                "Silme Onayı", JOptionPane.YES_NO_OPTION);
        
        if (confirm != JOptionPane.YES_OPTION) return;

        String sql = "Üyeler".equals(type) ? "DELETE FROM members WHERE id=?" : "DELETE FROM yonetici WHERE id=?";

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
            loadData();
            JOptionPane.showMessageDialog(this, "Silme işlemi başarılı.");

        } catch (Exception e) { e.printStackTrace(); }
    }
}