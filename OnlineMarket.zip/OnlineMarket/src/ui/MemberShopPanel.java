package ui;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.sql.*;
import db.DBConnection;

public class MemberShopPanel extends JPanel {

    JTable table;
    DefaultTableModel model;
    int memberId;
    JLabel lblQty;
    JComboBox<String> cmbCategory;

    public MemberShopPanel(int memberId) {
        this.memberId = memberId;

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        add(createHeader(), BorderLayout.NORTH);
        add(createCenter(), BorderLayout.CENTER);
        add(createBottom(), BorderLayout.SOUTH);

        refreshAll();
    }

    private JPanel createHeader() {

        JPanel header = new JPanel(new BorderLayout());
        header.setPreferredSize(new Dimension(0, 70));
        header.setBackground(Color.WHITE);
        header.setBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(200, 200, 200))
        );

        JLabel lblTitle = new JLabel("Ürün Listesi");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setBorder(BorderFactory.createEmptyBorder(0, 30, 0, 0));

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 18));
        right.setOpaque(false);

        JLabel lblCat = new JLabel("Kategori:");
        lblCat.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        cmbCategory = new JComboBox<>();
        cmbCategory.setPreferredSize(new Dimension(160, 30));
        cmbCategory.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        cmbCategory.addActionListener(e -> {
            String selected = (String) cmbCategory.getSelectedItem();
            if ("Tümü".equals(selected)) {
                loadProducts(null);
            } else {
                loadProducts(selected);
            }
        });

        JButton btnRefresh = new JButton("Yenile");
        btnRefresh.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btnRefresh.setFocusPainted(false);
        btnRefresh.setBackground(new Color(240, 240, 240));

        btnRefresh.addActionListener(e -> refreshAll());

        right.add(lblCat);
        right.add(cmbCategory);
        right.add(btnRefresh);

        header.add(lblTitle, BorderLayout.WEST);
        header.add(right, BorderLayout.EAST);

        return header;
    }

    private JScrollPane createCenter() {

    	model = new DefaultTableModel() {
    	    @Override
    	    public boolean isCellEditable(int r, int c) {
    	        return false;
    	    }
    	};

    	model.addColumn("ID");
    	model.addColumn("Ürün Adı");
    	model.addColumn("Kategori");
    	model.addColumn("Miktar");
    	model.addColumn("Fiyat");
    	model.addColumn("Stok");


        table = new JTable(model);
        table.setRowHeight(38);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setForeground(Color.BLACK);

        table.setBackground(Color.WHITE);

        table.setSelectionBackground(new Color(210, 210, 210));
        table.setSelectionForeground(Color.BLACK);

        table.setGridColor(new Color(150, 150, 150));
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(true);

        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(
                    JTable table, Object value, boolean isSelected,
                    boolean hasFocus, int row, int column) {

                Component c = super.getTableCellRendererComponent(
                        table, value, isSelected, hasFocus, row, column);

                if (!isSelected) {
                    c.setBackground(new Color(245, 245, 245));
                }
                return c;
            }
        });

        JTableHeader th = table.getTableHeader();
        th.setFont(new Font("Segoe UI", Font.BOLD, 13));
        th.setBackground(new Color(235, 235, 235));
        th.setForeground(Color.BLACK);
        th.setBorder(BorderFactory.createLineBorder(new Color(150, 150, 150)));

        table.getColumnModel().getColumn(0).setMaxWidth(60);  
        table.getColumnModel().getColumn(5).setMaxWidth(80);  
        table.getColumnModel().getColumn(4)
        .setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            protected void setValue(Object value) {
                if (value instanceof Number) {
                    setText(value + " TL");
                } else {
                    super.setValue(value);
                }
            }
        });



        JScrollPane sp = new JScrollPane(table);

        // 🔹 TABLO DIŞI ALANLAR TAM BEYAZ
        sp.getViewport().setBackground(Color.WHITE);
        sp.setBackground(Color.WHITE);
        sp.setBorder(BorderFactory.createEmptyBorder(15, 30, 15, 30));

        return sp;
    }
    private JPanel createBottom() {

        JPanel bottom = new JPanel(new GridBagLayout());
        bottom.setBackground(Color.WHITE);
        bottom.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0));

        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(5, 5, 5, 5);

        JButton btnMinus = new JButton("-");
        JButton btnPlus = new JButton("+");

        lblQty = new JLabel("1", SwingConstants.CENTER);
        lblQty.setPreferredSize(new Dimension(40, 30));
        lblQty.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        JButton btnAddCart = new JButton("Sepete Ekle");
        btnAddCart.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnAddCart.setBackground(new Color(45, 118, 232));
        btnAddCart.setForeground(Color.WHITE);
        btnAddCart.setFocusPainted(false);
        btnAddCart.setPreferredSize(new Dimension(160, 40));

        gc.gridx = 0; bottom.add(btnMinus, gc);
        gc.gridx = 1; bottom.add(lblQty, gc);
        gc.gridx = 2; bottom.add(btnPlus, gc);
        gc.gridx = 3; gc.insets = new Insets(5, 20, 5, 5);
        bottom.add(btnAddCart, gc);

        btnPlus.addActionListener(e -> {
            int q = Integer.parseInt(lblQty.getText());
            lblQty.setText(String.valueOf(q + 1));
        });

        btnMinus.addActionListener(e -> {
            int q = Integer.parseInt(lblQty.getText());
            if (q > 1) lblQty.setText(String.valueOf(q - 1));
        });

        btnAddCart.addActionListener(e -> addToCart());

        return bottom;
    }
    void refreshAll() {
        loadCategories();
        loadProducts(null);
    }

    void loadCategories() {
        cmbCategory.removeAllItems();
        cmbCategory.addItem("Tümü");

        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT kategori_adi FROM kategoriler ORDER BY kategori_adi")) {

            while (rs.next()) {
                cmbCategory.addItem(rs.getString("kategori_adi"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void loadProducts(String kategori) {

        model.setRowCount(0);

        String sql =
            "SELECT u.id, u.urun_adi, k.kategori_adi, " +
            "u.birim_miktar, u.birim, u.fiyat, u.stok " +
            "FROM urunler u " +
            "LEFT JOIN kategoriler k ON u.kategori_id = k.id " +
            "WHERE u.stok > 0";

        if (kategori != null) {
            sql += " AND k.kategori_adi = ?";
        }

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            if (kategori != null) {
                ps.setString(1, kategori);
            }

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("urun_adi"),
                    rs.getString("kategori_adi"),
                    rs.getDouble("birim_miktar") + " " + rs.getString("birim"), 
                    rs.getDouble("fiyat"), 
                    rs.getInt("stok")   
                });
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    void addToCart() {

        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Ürün seçiniz");
            return;
        }

        int productId = (int) model.getValueAt(row, 0);
        int stok     = (int) model.getValueAt(row, 5); 
        int adet     = Integer.parseInt(lblQty.getText());

        if (adet > stok) {
            JOptionPane.showMessageDialog(this, "Yeterli stok yok!");
            return;
        }

        try (Connection c = DBConnection.getConnection()) {

            int sepetId;

            PreparedStatement ps1 = c.prepareStatement(
                    "SELECT id FROM sepet WHERE uye_id=? AND durum='YENI'");
            ps1.setInt(1, memberId);
            ResultSet rs = ps1.executeQuery();

            if (rs.next()) {
                sepetId = rs.getInt("id");
            } else {
                PreparedStatement ps2 = c.prepareStatement(
                        "INSERT INTO sepet (uye_id, durum) VALUES (?, 'YENI')",
                        Statement.RETURN_GENERATED_KEYS);
                ps2.setInt(1, memberId);
                ps2.executeUpdate();
                rs = ps2.getGeneratedKeys();
                rs.next();
                sepetId = rs.getInt(1);
            }

            PreparedStatement ps3 = c.prepareStatement(
                    "INSERT INTO sepet_urun (sepet_id, urun_id, adet) VALUES (?,?,?) " +
                    "ON DUPLICATE KEY UPDATE adet=adet+?");
            ps3.setInt(1, sepetId);
            ps3.setInt(2, productId);
            ps3.setInt(3, adet);
            ps3.setInt(4, adet);
            ps3.executeUpdate();

            JOptionPane.showMessageDialog(this, "Ürün sepete eklendi");
            lblQty.setText("1");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
