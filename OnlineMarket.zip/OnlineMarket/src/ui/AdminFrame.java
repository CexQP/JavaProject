package ui;

import javax.swing.*;

import OnlineMarket.BaseFrame;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdminFrame extends BaseFrame {

    public AdminFrame() {

        setTitle("Çiftlik Otomasyonu - Yönetici Paneli");
        setSize(1400, 850);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);
        add(mainPanel);


        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(45, 118, 232)); 
        header.setPreferredSize(new Dimension(0, 70));
        header.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20)); 

        JLabel lblTitle = new JLabel("Yönetici Kontrol Paneli");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(Color.WHITE);
        header.add(lblTitle, BorderLayout.WEST);


        JPanel rightHeaderPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        rightHeaderPanel.setOpaque(false); 

        JLabel lblSub = new JLabel("Hoşgeldiniz, Admin");
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        lblSub.setForeground(new Color(220, 220, 220));
        rightHeaderPanel.add(lblSub);


        JButton btnLogout = new JButton("Çıkış");
        btnLogout.setBackground(new Color(231, 76, 60)); 
        btnLogout.setForeground(Color.WHITE);
        btnLogout.setFocusPainted(false);
        btnLogout.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnLogout.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        

        btnLogout.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); 
                new MainLoginFrame().setVisible(true); 
            }
        });
        
        rightHeaderPanel.add(btnLogout);
        header.add(rightHeaderPanel, BorderLayout.EAST);

        mainPanel.add(header, BorderLayout.NORTH);

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 14));
        tabbedPane.setBackground(Color.WHITE);
        
        UIManager.put("TabbedPane.contentBorderInsets", new Insets(10, 10, 10, 10));

        tabbedPane.addTab("Ürün Yönetimi", new ImageIcon(), new ProductManager(), "Ürün Ekleme ve Listeleme İşlemleri");

        tabbedPane.addTab("Sipariş Onayları", new CartApprovePanel());

        tabbedPane.addTab("Kullanıcı Yönetimi", new MemberAdminPanel());

        tabbedPane.addTab("Yeni Admin Ekle", new AdminRegisterPanel());

        mainPanel.add(tabbedPane, BorderLayout.CENTER);
    }
}