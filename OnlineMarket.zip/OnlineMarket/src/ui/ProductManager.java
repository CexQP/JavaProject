package ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.DefaultCellEditor;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Path2D;
import java.sql.*;
import db.DBConnection;

public class ProductManager extends JPanel {
    private JTextField txtUrunAdi, txtFiyat, txtStok, txtYeniKategori, txtBirimMiktar;
    private JComboBox<CategoryItem> cmbKategoriEkle;
    private JComboBox<String> cmbBirim;
    private JTable table;
    private DefaultTableModel model;
    private JComboBox<CategoryItem> cmbKategoriFiltre;

    public ProductManager() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setDividerLocation(400);
        splitPane.setDividerSize(0);
        splitPane.setBorder(null);

        splitPane.setLeftComponent(createRegisterPanel());
        splitPane.setRightComponent(createListPanel());

        add(splitPane, BorderLayout.CENTER);

        refreshAllData(); 
    }

    private JPanel createRegisterPanel() {
        JPanel panel = new JPanel(null);
        panel.setBackground(Color.WHITE);
        panel.setBorder(new MatteBorder(0, 0, 0, 1, new Color(220, 220, 220)));

        int leftMargin = 40;
        int topMargin = 40;
        int w = 280;
        int gap = 60; 
        
        JLabel lblTitle = new JLabel("Ürün Ekle");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(new Color(45, 118, 232));
        lblTitle.setBounds(leftMargin, topMargin, 200, 30);
        panel.add(lblTitle);

        int y = topMargin + 60;

        addLabel(panel, "Ürün Adı", leftMargin, y);
        txtUrunAdi = addTextField(panel, leftMargin, y + 25, w);

        y += gap;
        addLabel(panel, "Fiyat (TL)", leftMargin, y);
        txtFiyat = addTextField(panel, leftMargin, y + 25, w);

        y += gap;
        addLabel(panel, "Stok Miktarı", leftMargin, y);
        txtStok = addTextField(panel, leftMargin, y + 25, w);

        y += gap;
        addLabel(panel, "Miktar & Birim", leftMargin, y);
        txtBirimMiktar = addTextField(panel, leftMargin, y + 25, 130);

        cmbBirim = new JComboBox<>(new String[]{"ADET", "KG", "GR", "LT", "PKT"});
        cmbBirim.setBounds(leftMargin + 140, y + 25, 140, 35);
        cmbBirim.setBackground(Color.WHITE);
        panel.add(cmbBirim);

        y += gap;
        addLabel(panel, "Kategori", leftMargin, y);
        cmbKategoriEkle = new JComboBox<>();
        cmbKategoriEkle.setBounds(leftMargin, y + 25, 190, 35);
        panel.add(cmbKategoriEkle);

        JButton btnKatSil = new JButton("Sil");
        btnKatSil.setBounds(leftMargin + 200, y + 25, 80, 35);
        btnKatSil.setBackground(new Color(220, 53, 69));
        btnKatSil.setForeground(Color.WHITE);
        btnKatSil.addActionListener(e -> deleteCategory());
        panel.add(btnKatSil);

        y += gap;
        addLabel(panel, "Yeni Kategori", leftMargin, y);
        txtYeniKategori = addTextField(panel, leftMargin, y + 25, 190);

        JButton btnKatEkle = new JButton("Ekle");
        btnKatEkle.setBounds(leftMargin + 200, y + 25, 80, 35);
        btnKatEkle.setBackground(new Color(40, 167, 69));
        btnKatEkle.setForeground(Color.WHITE);
        btnKatEkle.addActionListener(e -> addCategory());
        panel.add(btnKatEkle);

        y += gap + 20;
        JButton btnSave = new JButton("ÜRÜNÜ KAYDET");
        btnSave.setBounds(leftMargin, y, w, 45);
        btnSave.setBackground(new Color(45, 118, 232));
        btnSave.setForeground(Color.WHITE);
        btnSave.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnSave.addActionListener(e -> addProduct());
        panel.add(btnSave);

        return panel;
    }
    private JPanel createListPanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setBackground(Color.WHITE);
        panel.setBorder(new EmptyBorder(30, 30, 30, 30));

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(Color.WHITE);

        JLabel lblListTitle = new JLabel("Ürün Listesi");
        lblListTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));

        cmbKategoriFiltre = new JComboBox<>();
        cmbKategoriFiltre.setPreferredSize(new Dimension(160, 35));
        cmbKategoriFiltre.addActionListener(e -> loadProductsToTable());

        JButton btnRefresh = new JButton("Yenile");
        btnRefresh.addActionListener(e -> refreshAllData());

        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        filterPanel.setBackground(Color.WHITE);
        filterPanel.add(new JLabel("Kategori:"));
        filterPanel.add(cmbKategoriFiltre);
        filterPanel.add(btnRefresh);

        topPanel.add(lblListTitle, BorderLayout.WEST);
        topPanel.add(filterPanel, BorderLayout.EAST);
        panel.add(topPanel, BorderLayout.NORTH);

        model = new DefaultTableModel(
                new String[]{"ID", "Ürün Adı", "Kategori", "Miktar", "Fiyat", "Stok", "İşlem"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return c == 6; }
        };

        table = new JTable(model);
        table.setRowHeight(45);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setBackground(new Color(248, 249, 250));

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));

        table.getColumnModel().getColumn(0).setMinWidth(0);
        table.getColumnModel().getColumn(0).setMaxWidth(0);
        table.getColumnModel().getColumn(6).setCellRenderer(new TableActionCellRender());
        table.getColumnModel().getColumn(6).setCellEditor(new TableActionCellEditor(new TableActionEvent() {
            @Override
            public void onEdit(int row) {
                if (table.isEditing()) table.getCellEditor().stopCellEditing();
                int id = (int) table.getValueAt(row, 0);
                new ProductUpdateDialog(id, ProductManager.this).setVisible(true);
            }

            @Override
            public void onDelete(int row) {
                int id = (int) table.getValueAt(row, 0);
                deleteProduct(id);
            }
        }));
        table.getColumnModel().getColumn(6).setMinWidth(110);
        table.getColumnModel().getColumn(6).setMaxWidth(110);

        JScrollPane sp = new JScrollPane(table);
        sp.getViewport().setBackground(new Color(248, 249, 250));
        panel.add(sp, BorderLayout.CENTER);

        return panel;
    }
    private void refreshAllData() {
        loadCategories();
        loadProductsToTable();
    }
    public void loadProducts() {
        loadProductsToTable();
    }

    private void loadCategories() {
        cmbKategoriEkle.removeAllItems();
        cmbKategoriFiltre.removeAllItems();
        cmbKategoriFiltre.addItem(new CategoryItem(0, "Tümü"));

        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM kategoriler ORDER BY kategori_adi")) {
            while (rs.next()) {
                CategoryItem item = new CategoryItem(rs.getInt("id"), rs.getString("kategori_adi"));
                cmbKategoriEkle.addItem(item);
                cmbKategoriFiltre.addItem(item);
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void loadProductsToTable() {
        model.setRowCount(0);
        CategoryItem filter = (CategoryItem) cmbKategoriFiltre.getSelectedItem();
        String sql = "SELECT u.id, u.urun_adi, u.fiyat, u.stok, u.birim_miktar, u.birim, k.kategori_adi FROM urunler u LEFT JOIN kategoriler k ON u.kategori_id=k.id";
        if (filter != null && filter.id != 0) sql += " WHERE u.kategori_id=" + filter.id;

        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("id"), rs.getString("urun_adi"), rs.getString("kategori_adi"),
                    rs.getDouble("birim_miktar") + " " + rs.getString("birim"),
                    rs.getDouble("fiyat") + " TL", rs.getInt("stok"), null
                });
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void addProduct() {
        if (cmbKategoriEkle.getSelectedItem() == null) return;
        try {
            String ad = txtUrunAdi.getText().trim();
            double fiyat = Double.parseDouble(txtFiyat.getText());
            int stok = Integer.parseInt(txtStok.getText());
            double miktar = Double.parseDouble(txtBirimMiktar.getText());
            int kId = ((CategoryItem) cmbKategoriEkle.getSelectedItem()).id;
            String birim = cmbBirim.getSelectedItem().toString();

            try (Connection c = DBConnection.getConnection();
                 PreparedStatement ps = c.prepareStatement("INSERT INTO urunler (urun_adi, fiyat, stok, kategori_id, birim_miktar, birim) VALUES (?,?,?,?,?,?)")) {
                ps.setString(1, ad); ps.setDouble(2, fiyat); ps.setInt(3, stok);
                ps.setInt(4, kId); ps.setDouble(5, miktar); ps.setString(6, birim);
                ps.executeUpdate();
                loadProductsToTable();
                txtUrunAdi.setText(""); txtFiyat.setText(""); txtStok.setText(""); txtBirimMiktar.setText("");
                JOptionPane.showMessageDialog(this, "Ürün Eklendi");
            }
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Hatalı Giriş!"); }
    }

    private void addCategory() {
        String ad = txtYeniKategori.getText().trim();
        if(ad.isEmpty()) return;
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement("INSERT INTO kategoriler (kategori_adi) VALUES (?)")) {
            ps.setString(1, ad); ps.executeUpdate(); refreshAllData(); txtYeniKategori.setText("");
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void deleteCategory() {
        CategoryItem item = (CategoryItem) cmbKategoriEkle.getSelectedItem();
        if(item==null) return;
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement("DELETE FROM kategoriler WHERE id=?")) {
            ps.setInt(1, item.id); ps.executeUpdate(); refreshAllData();
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Bu kategoride ürün var!"); }
    }

    private void deleteProduct(int id) {
        if (JOptionPane.showConfirmDialog(this, "Silinsin mi?", "Onay", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement("DELETE FROM urunler WHERE id=?")) {
                ps.setInt(1, id); ps.executeUpdate(); loadProductsToTable();
            } catch (Exception e) { e.printStackTrace(); }
        }
    }
    private void addLabel(JPanel p, String t, int x, int y) {
        JLabel l = new JLabel(t); l.setFont(new Font("Segoe UI", Font.BOLD, 12));
        l.setForeground(Color.DARK_GRAY); l.setBounds(x, y, 200, 20); p.add(l);
    }
    private JTextField addTextField(JPanel p, int x, int y, int w) {
        JTextField tf = new JTextField(); tf.setBounds(x, y, w, 35);
        tf.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(200,200,200)), BorderFactory.createEmptyBorder(5,10,5,10)));
        p.add(tf); return tf;
    }

    static class CategoryItem {
        int id; String ad;
        CategoryItem(int id, String ad) { this.id = id; this.ad = ad; }
        public String toString() { return ad; }
    }
    public interface TableActionEvent { void onEdit(int row); void onDelete(int row); }
    public class TableActionCellRender extends DefaultTableCellRenderer {
        public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int r, int c) {
            PanelAction p = new PanelAction(); p.setBackground(s ? t.getSelectionBackground() : new Color(248, 249, 250)); return p;
        }
    }
    public class TableActionCellEditor extends DefaultCellEditor {
        TableActionEvent ev;
        public TableActionCellEditor(TableActionEvent ev) { super(new JCheckBox()); this.ev = ev; }
        public Component getTableCellEditorComponent(JTable t, Object v, boolean s, int r, int c) {
            PanelAction p = new PanelAction(); p.initEvent(ev, r); return p;
        }
    }
    public class PanelAction extends JPanel {
        ActionButton edit = new ActionButton("edit", new Color(42,196,114));
        ActionButton del = new ActionButton("delete", new Color(255,77,77));
        PanelAction() { setLayout(new FlowLayout(FlowLayout.CENTER, 5, 0)); add(edit); add(del); }
        void initEvent(TableActionEvent e, int r) { edit.addActionListener(a->e.onEdit(r)); del.addActionListener(a->e.onDelete(r)); }
    }
    public class ActionButton extends JButton {
        boolean over = false;
        String type;
        Color c;

        ActionButton(String type, Color c) {
            this.type = type;
            this.c = c;

            setContentAreaFilled(false);
            setBorder(null);
            setPreferredSize(new Dimension(28, 28));
            setCursor(new Cursor(Cursor.HAND_CURSOR));

            addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) { over = true; repaint(); }
                public void mouseExited(MouseEvent e) { over = false; repaint(); }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(c.getRed(), c.getGreen(), c.getBlue(), over ? 90 : 40));
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);

            g2.setColor(c);

            if (type.equals("edit")) {
                drawPencil(g2);
            } else if (type.equals("delete")) {
                drawTrash(g2);
            }

            g2.dispose();
        }

        private void drawPencil(Graphics2D g2) {
            int cx = getWidth() / 2;
            int cy = getHeight() / 2;

            Path2D pencil = new Path2D.Double();
            pencil.moveTo(cx - 6, cy + 4);
            pencil.lineTo(cx + 4, cy - 6);
            pencil.lineTo(cx + 7, cy - 3);
            pencil.lineTo(cx - 3, cy + 7);
            pencil.closePath();
            Path2D tip = new Path2D.Double();
            tip.moveTo(cx + 4, cy - 6);
            tip.lineTo(cx + 7, cy - 9);
            tip.lineTo(cx + 10, cy - 6);
            tip.closePath();

            g2.fill(pencil);
            g2.fill(tip);
        }
        private void drawTrash(Graphics2D g2) {
            int x = 8, y = 6;
            g2.fillRect(x + 2, y, 8, 3); 
            g2.fillRect(x, y + 3, 12, 2);  
            g2.fillRect(x + 2, y + 6, 8, 10);
        }
    }

}