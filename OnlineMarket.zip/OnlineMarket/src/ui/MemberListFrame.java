package ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

import db.DBConnection;

public class MemberListFrame extends JFrame {

    JTable table;
    DefaultTableModel model;

    public MemberListFrame() {
        setTitle("Üye Listesi");
        setSize(400,300);
        setLocationRelativeTo(null);

        model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Ad");
        model.addColumn("Soyad");
        model.addColumn("Kullanıcı Adı");

        table = new JTable(model);
        add(new JScrollPane(table));

        loadMembers();
    }

    void loadMembers() {
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM members")) {

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("surname"),
                        rs.getString("username")
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
