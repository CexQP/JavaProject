package ui;

import db.DBConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.sql.*;

public class MemberOrdersPanel extends JPanel {

    int memberId;

    JTable orderTable, detailTable;
    DefaultTableModel orderModel, detailModel;

    JLabel lblToplam;
    JPanel redPanel;
    JLabel lblRedNedeni;

    public MemberOrdersPanel(int memberId) {
        this.memberId = memberId;

        setLayout(new BorderLayout(10, 10));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        orderModel = new DefaultTableModel(
                new String[]{"Sipariş ID", "Durum", "Tarih"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };

        orderTable = createTable(orderModel);
        orderTable.getColumnModel().getColumn(1)
                .setCellRenderer(new StatusCellRenderer());

        JScrollPane orderScroll = createScroll(orderTable);

        detailModel = new DefaultTableModel(
                new String[]{"Ürün Adı", "Adet", "Birim Fiyat", "Ara Toplam"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };

        detailTable = createTable(detailModel);

        // TL renderer
        detailTable.getColumnModel().getColumn(2).setCellRenderer(tlRenderer());
        detailTable.getColumnModel().getColumn(3).setCellRenderer(tlRenderer());

        JScrollPane detailScroll = createScroll(detailTable);

        lblToplam = new JLabel("Toplam: 0 TL", SwingConstants.RIGHT);
        lblToplam.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblToplam.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 10));

        redPanel = new JPanel(new BorderLayout());
        redPanel.setBackground(Color.WHITE);
        redPanel.setBorder(
                BorderFactory.createTitledBorder(
                        BorderFactory.createLineBorder(new Color(200, 200, 200)),
                        "Red Nedeni"
                )
        );

        lblRedNedeni = new JLabel();
        lblRedNedeni.setForeground(Color.RED);
        lblRedNedeni.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblRedNedeni.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        redPanel.add(lblRedNedeni, BorderLayout.CENTER);
        redPanel.setVisible(false);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(Color.WHITE);
        bottomPanel.add(lblToplam, BorderLayout.NORTH);
        bottomPanel.add(redPanel, BorderLayout.SOUTH);

        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBackground(Color.WHITE);
        rightPanel.add(detailScroll, BorderLayout.CENTER);
        rightPanel.add(bottomPanel, BorderLayout.SOUTH);

        JSplitPane splitPane = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT,
                orderScroll,
                rightPanel
        );
        splitPane.setDividerLocation(350);
        splitPane.setBorder(null);

        add(splitPane, BorderLayout.CENTER);

        orderTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && orderTable.getSelectedRow() != -1) {
                int sepetId = (int) orderModel.getValueAt(
                        orderTable.getSelectedRow(), 0);
                String durum = orderModel.getValueAt(
                        orderTable.getSelectedRow(), 1).toString();
                loadDetails(sepetId, durum);
            }
        });

        loadOrders();
    }

    private JTable createTable(DefaultTableModel model) {
        JTable table = new JTable(model);
        table.setRowHeight(36);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setBackground(Color.WHITE);
        table.setSelectionBackground(new Color(210, 210, 210));
        table.setSelectionForeground(Color.BLACK);
        table.setGridColor(new Color(180, 180, 180));
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(true);

        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(
                    JTable table, Object value, boolean isSelected,
                    boolean hasFocus, int row, int column) {

                Component c = super.getTableCellRendererComponent(
                        table, value, isSelected, hasFocus, row, column);

                if (!isSelected) {
                    c.setBackground(new Color(245, 245, 245));
                }
                return c;
            }
        });

        JTableHeader th = table.getTableHeader();
        th.setFont(new Font("Segoe UI", Font.BOLD, 13));
        th.setBackground(new Color(235, 235, 235));
        th.setForeground(Color.BLACK);
        th.setBorder(BorderFactory.createLineBorder(new Color(180, 180, 180)));

        return table;
    }

    private JScrollPane createScroll(JTable table) {
        JScrollPane sp = new JScrollPane(table);
        sp.getViewport().setBackground(Color.WHITE);
        sp.setBackground(Color.WHITE);
        sp.setBorder(BorderFactory.createEmptyBorder());
        return sp;
    }

    private DefaultTableCellRenderer tlRenderer() {
        return new DefaultTableCellRenderer() {
            @Override
            protected void setValue(Object value) {
                if (value instanceof Number) {
                    setText(value + " TL");
                } else {
                    super.setValue(value);
                }
            }
        };
    }

    void loadOrders() {
        orderModel.setRowCount(0);

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT id, durum, tarih FROM sepet WHERE uye_id=?")) {

            ps.setInt(1, memberId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                orderModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("durum"),
                        rs.getTimestamp("tarih")
                });
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void loadDetails(int sepetId, String durum) {

        detailModel.setRowCount(0);
        redPanel.setVisible(false);
        double toplam = 0;

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT u.urun_adi, su.adet, u.fiyat " +
                             "FROM sepet_urun su " +
                             "JOIN urunler u ON su.urun_id = u.id " +
                             "WHERE su.sepet_id=?")) {

            ps.setInt(1, sepetId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int adet = rs.getInt("adet");
                double fiyat = rs.getDouble("fiyat");
                double ara = adet * fiyat;
                toplam += ara;

                detailModel.addRow(new Object[]{
                        rs.getString("urun_adi"),
                        adet,
                        fiyat,
                        ara
                });
            }

            lblToplam.setText("Toplam: " + toplam + " TL");

        } catch (Exception e) {
            e.printStackTrace();
        }

        if ("REDDEDILDI".equals(durum)) {
            try (Connection c = DBConnection.getConnection();
                 PreparedStatement ps = c.prepareStatement(
                         "SELECT red_nedeni FROM sepet WHERE id=?")) {

                ps.setInt(1, sepetId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    lblRedNedeni.setText(rs.getString("red_nedeni"));
                    redPanel.setVisible(true);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    static class StatusCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(
                JTable table, Object value, boolean isSelected,
                boolean hasFocus, int row, int column) {

            Component c = super.getTableCellRendererComponent(
                    table, value, isSelected, hasFocus, row, column);

            String durum = value.toString();

            if ("ONAYLANDI".equals(durum)) {
                c.setForeground(new Color(0, 140, 0));
            } else if ("REDDEDILDI".equals(durum)) {
                c.setForeground(Color.RED);
            } else {
                c.setForeground(new Color(255, 140, 0));
            }

            return c;
        }
    }
}
