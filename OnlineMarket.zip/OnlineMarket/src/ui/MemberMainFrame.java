package ui;

import javax.swing.*;

import OnlineMarket.BaseFrame;

import java.awt.*;
import java.sql.*;
import db.DBConnection;

public class MemberMainFrame extends BaseFrame {

    int memberId;
    JLabel lblWelcome;

    public MemberMainFrame(int memberId) {

        this.memberId = memberId;

        setTitle("Üye Paneli");
        setSize(1400, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel header = new JPanel(new BorderLayout());
        header.setPreferredSize(new Dimension(0, 70));
        header.setBackground(new Color(51, 122, 233)); 

        JLabel lblTitle = new JLabel("Üye Paneli");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBorder(BorderFactory.createEmptyBorder(0, 30, 0, 0));

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 18));
        right.setOpaque(false);

        lblWelcome = new JLabel("Hoşgeldiniz");
        lblWelcome.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblWelcome.setForeground(Color.WHITE);

        JButton btnExit = new JButton("Çıkış");
        btnExit.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnExit.setBackground(new Color(217, 83, 79)); 
        btnExit.setForeground(Color.WHITE);
        btnExit.setFocusPainted(false);
        btnExit.setBorderPainted(false);
        btnExit.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnExit.setPreferredSize(new Dimension(80, 35));

        btnExit.addActionListener(e -> {
            dispose();
            new MainLoginFrame().setVisible(true);
        });

        right.add(lblWelcome);
        right.add(btnExit);

        header.add(lblTitle, BorderLayout.WEST);
        header.add(right, BorderLayout.EAST);

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        MemberShopPanel shopPanel = new MemberShopPanel(memberId);
        MemberCartPanel cartPanel = new MemberCartPanel(memberId);
        MemberOrdersPanel ordersPanel = new MemberOrdersPanel(memberId);
        MemberProfilePanel profilePanel = new MemberProfilePanel(memberId);

        tabs.addTab("Mağaza", shopPanel);
        tabs.addTab("Sepetim", cartPanel);
        tabs.addTab("Siparişlerim", ordersPanel);
        tabs.addTab("Kişisel Bilgiler", profilePanel);

        tabs.addChangeListener(e -> {
            if (tabs.getSelectedComponent() == cartPanel) {
                cartPanel.refresh();
            }
            if (tabs.getSelectedComponent() == ordersPanel) {
                ordersPanel.loadOrders();
            }
        });

        add(header, BorderLayout.NORTH);
        add(tabs, BorderLayout.CENTER);

        loadMemberName(); 

        setVisible(true);
    }

    private void loadMemberName() {

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT name FROM members WHERE id=?")) {

            ps.setInt(1, memberId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                lblWelcome.setText("Hoşgeldiniz, " + rs.getString("name"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
