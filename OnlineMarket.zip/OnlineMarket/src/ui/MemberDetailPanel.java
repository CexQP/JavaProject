package ui;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import db.DBConnection;

public class MemberDetailPanel extends JFrame {

    public MemberDetailPanel(int memberId) {

        setTitle("Üye Detayı - ID: " + memberId);
        setSize(550, 420);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        JLabel lblTitle = new JLabel("Üye Bilgileri");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitle.setBounds(30, 20, 300, 30);
        add(lblTitle);

        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(null);
        infoPanel.setBackground(Color.WHITE);
        infoPanel.setBorder(BorderFactory.createLineBorder(new Color(230, 230, 230)));
        infoPanel.setBounds(30, 70, 475, 220);
        add(infoPanel);

        JLabel lblName = new JLabel();
        JLabel lblUsername = new JLabel();
        JLabel lblAddress = new JLabel();

        lblName.setBounds(20, 20, 430, 30);
        lblUsername.setBounds(20, 70, 430, 30);
        lblAddress.setBounds(20, 120, 430, 70);

        lblName.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        lblUsername.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        lblAddress.setFont(new Font("Segoe UI", Font.PLAIN, 15));

        infoPanel.add(lblName);
        infoPanel.add(lblUsername);
        infoPanel.add(lblAddress);

        JButton btnKapat = new JButton("Kapat");
        btnKapat.setBounds(325, 310, 180, 42);
        btnKapat.setBackground(new Color(45, 118, 232));
        btnKapat.setForeground(Color.WHITE);
        btnKapat.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnKapat.setFocusPainted(false);
        btnKapat.setBorderPainted(false);
        btnKapat.addActionListener(e -> dispose());
        add(btnKapat);

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT name, username, address FROM members WHERE id=?")) {

            ps.setInt(1, memberId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                lblName.setText("Ad Soyad:  " + rs.getString("name"));
                lblUsername.setText("Kullanıcı Adı:  " + rs.getString("username"));
                lblAddress.setText("<html>Adres:<br>" + rs.getString("address") + "</html>");
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Üye bilgileri yüklenemedi!",
                    "Hata",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
