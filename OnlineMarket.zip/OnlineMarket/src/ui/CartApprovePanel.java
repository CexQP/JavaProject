package ui;

import db.DBConnection;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.text.SimpleDateFormat;

public class CartApprovePanel extends JPanel {

    private JTable masterTable;
    private DefaultTableModel masterModel;

    private JTable detailTable;
    private DefaultTableModel detailModel;

    private JLabel lblSelectedInfo;
    private JButton btnApprove;
    private JButton btnReject;

    private int selectedSepetId = -1;

    public CartApprovePanel() {

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(Color.WHITE);
        topPanel.setBorder(new EmptyBorder(15, 20, 15, 20));

        JLabel lblTitle = new JLabel("Sepet Onay Ekranı");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));

        JButton btnRefresh = new JButton("Yenile");
        btnRefresh.addActionListener(e -> {
            loadPendingMaster();
            clearDetailPanel();
        });

        topPanel.add(lblTitle, BorderLayout.WEST);
        topPanel.add(btnRefresh, BorderLayout.EAST);
        add(topPanel, BorderLayout.NORTH);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setDividerLocation(650);
        splitPane.setDividerSize(5);
        splitPane.setBorder(null);

        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setBackground(Color.WHITE);
        leftPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY),
                "Bekleyen Siparişler",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Segoe UI", Font.BOLD, 14)
        ));

        masterModel = new DefaultTableModel() {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        masterModel.addColumn("ID");
        masterModel.addColumn("Üye");
        masterModel.addColumn("Adres");
        masterModel.addColumn("Durum");
        masterModel.addColumn("Tarih");

        masterTable = new JTable(masterModel);
        styleTable(masterTable);

        masterTable.getColumnModel()
                .getColumn(3)
                .setCellRenderer(new StatusRenderer());

        masterTable.getColumnModel().getColumn(0).setMaxWidth(60);
        masterTable.getColumnModel().getColumn(3).setMaxWidth(110);
        masterTable.getColumnModel().getColumn(4).setPreferredWidth(160);

        masterTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && masterTable.getSelectedRow() != -1) {
                int sepetId = (int) masterModel.getValueAt(masterTable.getSelectedRow(), 0);
                loadCartDetails(sepetId);
            }
        });

        leftPanel.add(new JScrollPane(masterTable), BorderLayout.CENTER);

        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBackground(new Color(250, 250, 250));
        rightPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY),
                "Sipariş Detayı",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Segoe UI", Font.BOLD, 14)
        ));

        lblSelectedInfo = new JLabel("Lütfen soldan bir sipariş seçiniz.");
        lblSelectedInfo.setBorder(new EmptyBorder(10, 10, 10, 10));
        lblSelectedInfo.setFont(new Font("Segoe UI", Font.ITALIC, 13));
        lblSelectedInfo.setForeground(Color.GRAY);
        rightPanel.add(lblSelectedInfo, BorderLayout.NORTH);

        detailModel = new DefaultTableModel() {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        detailModel.addColumn("Ürün");
        detailModel.addColumn("Adet");
        detailModel.addColumn("Birim Fiyat");
        detailModel.addColumn("Toplam");

        detailTable = new JTable(detailModel);
        styleTable(detailTable);
        rightPanel.add(new JScrollPane(detailTable), BorderLayout.CENTER);

        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        actionPanel.setBackground(new Color(250, 250, 250));

        btnApprove = new JButton("Onayla");
        btnReject = new JButton("Reddet");

        styleButton(btnApprove, new Color(40, 167, 69));
        styleButton(btnReject, new Color(220, 53, 69));

        btnApprove.setEnabled(false);
        btnReject.setEnabled(false);

        btnApprove.addActionListener(e -> approveOrder());
        btnReject.addActionListener(e -> rejectOrder());

        actionPanel.add(btnReject);
        actionPanel.add(btnApprove);

        rightPanel.add(actionPanel, BorderLayout.SOUTH);

        splitPane.setLeftComponent(leftPanel);
        splitPane.setRightComponent(rightPanel);

        add(splitPane, BorderLayout.CENTER);

        loadPendingMaster();
    }

    private void loadPendingMaster() {

        masterModel.setRowCount(0);
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm");

        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT s.id, m.name, m.address, s.durum, s.tarih " +
                     "FROM sepet s " +
                     "JOIN members m ON s.uye_id = m.id " +
                     "ORDER BY s.tarih DESC")) {

            while (rs.next()) {
                masterModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("address"),
                        rs.getString("durum"),
                        sdf.format(rs.getTimestamp("tarih"))
                });
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadCartDetails(int sepetId) {

        selectedSepetId = sepetId;
        detailModel.setRowCount(0);
        btnApprove.setEnabled(true);
        btnReject.setEnabled(true);

        lblSelectedInfo.setText("Seçili Sipariş ID: " + sepetId);
        lblSelectedInfo.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblSelectedInfo.setForeground(Color.BLACK);

        double toplam = 0;

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT u.urun_adi, su.adet, u.fiyat " +
                     "FROM sepet_urun su JOIN urunler u ON su.urun_id=u.id " +
                     "WHERE su.sepet_id=?")) {

            ps.setInt(1, sepetId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int adet = rs.getInt("adet");
                double fiyat = rs.getDouble("fiyat");
                double ara = adet * fiyat;
                toplam += ara;

                detailModel.addRow(new Object[]{
                        rs.getString("urun_adi"),
                        adet,
                        fiyat + " TL",
                        ara + " TL"
                });
            }

            detailModel.addRow(new Object[]{"TOPLAM", "", "", toplam + " TL"});

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void approveOrder() {

        if (selectedSepetId == -1) return;

        try (Connection c = DBConnection.getConnection()) {

            c.setAutoCommit(false);

            PreparedStatement psItems = c.prepareStatement(
                    "SELECT urun_id, adet FROM sepet_urun WHERE sepet_id=?");
            psItems.setInt(1, selectedSepetId);
            ResultSet rs = psItems.executeQuery();

            PreparedStatement psStock = c.prepareStatement(
                    "UPDATE urunler SET stok = stok - ? WHERE id=? AND stok >= ?");

            while (rs.next()) {
                int adet = rs.getInt("adet");
                int urunId = rs.getInt("urun_id");

                psStock.setInt(1, adet);
                psStock.setInt(2, urunId);
                psStock.setInt(3, adet);

                if (psStock.executeUpdate() == 0) {
                    throw new Exception("Stok yetersiz!");
                }
            }

            PreparedStatement ps = c.prepareStatement(
                    "UPDATE sepet SET durum='ONAYLANDI' WHERE id=?");
            ps.setInt(1, selectedSepetId);
            ps.executeUpdate();

            c.commit();
            JOptionPane.showMessageDialog(this, "Sipariş onaylandı");

            loadPendingMaster();
            clearDetailPanel();

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Hata: " + e.getMessage());
        }
    }

    private void rejectOrder() {

        if (selectedSepetId == -1) return;

        String reason = JOptionPane.showInputDialog(this, "Reddetme nedeni:");
        if (reason == null || reason.trim().isEmpty()) return;

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "UPDATE sepet SET durum='REDDEDILDI', red_nedeni=? WHERE id=?")) {

            ps.setString(1, reason);
            ps.setInt(2, selectedSepetId);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Sipariş reddedildi");
            loadPendingMaster();
            clearDetailPanel();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void clearDetailPanel() {
        selectedSepetId = -1;
        detailModel.setRowCount(0);
        lblSelectedInfo.setText("Lütfen soldan bir sipariş seçiniz.");
        lblSelectedInfo.setFont(new Font("Segoe UI", Font.ITALIC, 13));
        lblSelectedInfo.setForeground(Color.GRAY);
        btnApprove.setEnabled(false);
        btnReject.setEnabled(false);
    }

    private void styleButton(JButton btn, Color color) {
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setPreferredSize(new Dimension(130, 40));
    }

    private void styleTable(JTable table) {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(30);
        table.setSelectionBackground(new Color(232, 240, 254));
        table.setSelectionForeground(Color.BLACK);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.setShowHorizontalLines(true);
        table.setGridColor(new Color(230, 230, 230));
    }

    static class StatusRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(
                JTable table, Object value, boolean isSelected,
                boolean hasFocus, int row, int column) {

            Component c = super.getTableCellRendererComponent(
                    table, value, isSelected, hasFocus, row, column);

            if (!isSelected && value != null) {
                switch (value.toString()) {
                    case "BEKLIYOR":
                        c.setForeground(new Color(255, 140, 0));
                        break;
                    case "ONAYLANDI":
                        c.setForeground(new Color(0, 128, 0));
                        break;
                    case "REDDEDILDI":
                        c.setForeground(Color.RED);
                        break;
                    default:
                        c.setForeground(Color.BLACK);
                }
            }
            return c;
        }
    }
}
