package ui;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.sql.*;
import db.DBConnection;

public class MemberCartPanel extends JPanel {

    JTable table;
    DefaultTableModel model;
    int memberId;
    JLabel lblTotal;

    public MemberCartPanel(int memberId) {
        this.memberId = memberId;

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        add(createHeader(), BorderLayout.NORTH);
        add(createCenter(), BorderLayout.CENTER);
        add(createBottom(), BorderLayout.SOUTH);

        loadCart();
    }

    private JPanel createHeader() {

        JPanel header = new JPanel(new BorderLayout());
        header.setPreferredSize(new Dimension(0, 70));
        header.setBackground(Color.WHITE);
        header.setBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(200, 200, 200))
        );

        JLabel lblTitle = new JLabel("Sepetim");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setBorder(BorderFactory.createEmptyBorder(0, 30, 0, 0));

        header.add(lblTitle, BorderLayout.WEST);
        return header;
    }

    private JScrollPane createCenter() {

        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };

        model.addColumn("Ürün");
        model.addColumn("Adet");
        model.addColumn("Birim Fiyat");
        model.addColumn("Toplam");

        table = new JTable(model);
        table.setRowHeight(38);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setForeground(Color.BLACK);

        table.setBackground(Color.WHITE);

        table.setSelectionBackground(new Color(210, 210, 210));
        table.setSelectionForeground(Color.BLACK);

        table.setGridColor(new Color(150, 150, 150));
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(true);

        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(
                    JTable table, Object value, boolean isSelected,
                    boolean hasFocus, int row, int column) {

                Component c = super.getTableCellRendererComponent(
                        table, value, isSelected, hasFocus, row, column);

                if (!isSelected) {
                    c.setBackground(new Color(245, 245, 245));
                }
                return c;
            }
        });

        JTableHeader th = table.getTableHeader();
        th.setFont(new Font("Segoe UI", Font.BOLD, 13));
        th.setBackground(new Color(235, 235, 235));
        th.setForeground(Color.BLACK);
        th.setBorder(BorderFactory.createLineBorder(new Color(150, 150, 150)));

        JScrollPane sp = new JScrollPane(table);
        sp.getViewport().setBackground(Color.WHITE);
        sp.setBackground(Color.WHITE);
        sp.setBorder(BorderFactory.createEmptyBorder(15, 30, 15, 30));

        return sp;
    }

    private JPanel createBottom() {

        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setBackground(Color.WHITE);
        bottom.setBorder(BorderFactory.createEmptyBorder(10, 30, 20, 30));

        lblTotal = new JLabel("Toplam: 0 TL");
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 16));

        JButton btnApprove = new JButton("Sepeti Onayla");
        btnApprove.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnApprove.setBackground(new Color(45, 118, 232));
        btnApprove.setForeground(Color.WHITE);
        btnApprove.setFocusPainted(false);
        btnApprove.setPreferredSize(new Dimension(180, 40));

        btnApprove.addActionListener(e -> sendToApprove());

        bottom.add(lblTotal, BorderLayout.WEST);
        bottom.add(btnApprove, BorderLayout.EAST);

        return bottom;
    }

    public void refresh() {
        loadCart();
    }

    private void loadCart() {

        model.setRowCount(0);
        double total = 0;

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT u.urun_adi, su.adet, u.fiyat " +
                     "FROM sepet s " +
                     "JOIN sepet_urun su ON s.id = su.sepet_id " +
                     "JOIN urunler u ON su.urun_id = u.id " +
                     "WHERE s.uye_id=? AND s.durum='YENI'")) {

            ps.setInt(1, memberId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int adet = rs.getInt("adet");
                double fiyat = rs.getDouble("fiyat");
                double satirToplam = adet * fiyat;

                total += satirToplam;

                model.addRow(new Object[]{
                        rs.getString("urun_adi"),
                        adet,
                        fiyat + " TL",
                        satirToplam + " TL"
                });
            }

            lblTotal.setText("Toplam: " + total + " TL");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void sendToApprove() {

        if (model.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Sepet boş!");
            return;
        }

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "UPDATE sepet SET durum='BEKLIYOR' WHERE uye_id=? AND durum='YENI'")) {

            ps.setInt(1, memberId);
            int affected = ps.executeUpdate();

            if (affected > 0) {
                JOptionPane.showMessageDialog(this, "Sepet onaya gönderildi");
                refresh();
            } else {
                JOptionPane.showMessageDialog(this, "Gönderilecek aktif sepet yok");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
