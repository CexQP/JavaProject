package dao;

import java.sql.*;
import db.DBConnection;

public class UserDAO {
    public static int login(String kullaniciAdi, String sifre) {

        String sql = "SELECT id FROM members WHERE kullanici_adi=? AND sifre=?";

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, kullaniciAdi);
            ps.setString(2, sifre);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt("id");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return -1;
    }
}
