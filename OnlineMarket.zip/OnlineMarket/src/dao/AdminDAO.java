package dao;

import java.sql.*;
import db.DBConnection;

public class AdminDAO {

    public static boolean login(String kullaniciAdi, String sifre) {

        String sql = "SELECT * FROM yonetici WHERE kullanici_adi=? AND sifre=?";

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, kullaniciAdi);
            ps.setString(2, sifre);

            ResultSet rs = ps.executeQuery();
            return rs.next();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
